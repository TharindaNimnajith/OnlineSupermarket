// JavaScript source code for Delivery Details page

function delivery(form)
{    
    
    var errors = [];

    if(form.district.value == "")
    {
        errors.push("Please enter the delivery area!");
    }

    if(form.firstName.value == "")
    {
        errors.push("Please enter the first name!");
    }

    if(form.lastName.value == "")
    {
        errors.push("Please enter the last name!");
    }

    if(form.nic.value == "")
    {
        errors.push("Please enter the NIC!");
    }

    if(form.email.value == "")
    {
        errors.push("Please enter the e-mail!");
    }

    if (form.contactNumber.value == "")
    {
        errors.push("Please enter the contact number!");
    }

    if (form.address.value == "")
    {
        errors.push("Please enter the delivery address!");
    }

    var alphabeticExpression = /^[A-Za-z]+$/;

    if (form.firstName.value != "" && !firstName.value.match(alphabeticExpression))
    {
        errors.push("Please use letters only for your first name!");
    }

    if (form.lastName.value != "" && !lastName.value.match(alphabeticExpression))
    {
        errors.push("Please use letters only for your last name!");
    }

    var numericExpression = /^[0-9]+$/;

    if (form.contactNumber.value != "" && !contactNumber.value.match(numericExpression))
    {
        errors.push("Please use numbers only for your contact number!");
    }

    var emailExpression = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;

    if (form.email.value != "" && !email.value.match(emailExpression))
    {
        errors.push("Please insert a correct email address!");
    }

    if (errors.length > 0)
    {
        var message = "ERRORS: \n\n";

        for (var i = 0; i < errors.length; i++)
        {
            message += errors[i] + "\n";
        }

        alert(message);

        return false;
    }

    return true;
}



