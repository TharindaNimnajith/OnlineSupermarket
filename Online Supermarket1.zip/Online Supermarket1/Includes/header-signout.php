    <header>

        <div class="main_head">

            <div class="logo">
                <a href="Home.php">
                    <img src="Images/logo.jpg" alt="logo" />
                </a>
            </div>

            <div class="name">
                <a href="Home.php">
                    <h1>Store 2 Door </h1>
                </a>
            </div>

            <div class="topics">
                <a href="About Us.php" target="_blank">About Us </a>
                <a href="Customer Feedback.php" target="_blank">Customer Feedback </a>
                <a href="Contact Us.php" target="_blank">Contact Us </a>
                <a href="Privacy Policy.php" target="_blank">Privacy Policy </a>
            </div>

            <div class="cart">
                <a href="Shopping Cart.php" target="_blank">
                    <img src="Images/cart.jpg" alt="shopping cart" />
                </a>
            </div>

            <div class="shopping">
                <a href="Shopping Cart.php" target="_blank">My Shopping Cart </a>
            </div>

            <div class="signOut">
                <a href="Home.php">Sign Out</a>
            </div>

            <div class="profile">
                <a href="User Account.php">
                    <img src="Images/img_avatar.png" alt="profile picture" class="image" />
                </a>
                <div class="middle">
                    <div class="text_profile">
                        <a href="User Account.php">View Profile </a>
                    </div>
                </div>
            </div>

        </div>

        <div class="next">

            <div class="offers">
                <a href="Weekly Offers.php" target="_blank">Weekly Offers</a>
            </div>

            <div class="search">
                <input type="text" placeholder=" Search Items Here..." name="search" />
            </div>

        </div>

        <div class="navigation">
            <button><a href="Household.php">Household</a></button>
            <button><a href="Grocery.php">Grocery</a></button>
            <button><a href="Chilled.php">Chilled</a></button>
            <button><a href="Pharmacy.php">Pharmacy</a></button>
            <button><a href="Liquor.php">Liquor</a></button>
            <button><a href="Beverages.php">Beverages</a></button>
            <button><a href="Frozen Food.php">Frozen Food</a></button>
            <button><a href="Meat.php">Meat</a></button>
            <button><a href="Fish.php">Fish</a></button>
            <button><a href="Vegetables.php">Vegetables</a></button>
            <button><a href="Fruits.php">Fruits</a></button>
        </div>

    </header>