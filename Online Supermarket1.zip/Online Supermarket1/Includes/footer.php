    <footer class="footer">

        <div class="text">
            <a href="Contact Us.php" target="_blank">Contact Us</a>
            <br />
            <p>&#169; 2018 All rights reserved. Store2door Limited &emsp; Call Us 5:30am - midnight, 7 days a week, on 555 555 5555 &emsp; E mail us at store2door@gmail.com</p>
            
        </div>

        <div class="cards">
            <img src="Images/card collection.jpg" alt="payment cards" />
        </div>

        <div class="social">
            <img src="Images/facebook.png" class="simg" />
            <img src="Images/twitter.png" class="simg" />
            <img src="Images/google+.jpg" class="simg"  />
            <img src="Images/pintarest.png" class="simg" />
            <img src="Images/insta.png" class="simg" />
            
        </div>

        <div class="dtext">
            <p>Download Apps</p>
        </div>
    
    <div class="download">
        <img src="Images/apple.png"class="dimg" />
        <img src="Images/play.png" class="dimg" />
    </div>


    </footer>